# Machinetestnimap
1. Category Master with CRUD operations   2. Product Master with CRUD operations. A product belongs to a category.  3. Product list should be displayed with following Columns :    ProductId  ProductName  CategoryId  CategoryName
